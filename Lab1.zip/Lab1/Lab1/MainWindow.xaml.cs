﻿using LibraryLab1;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Xml;

namespace Lab1
{
    public partial class MainWindow : Window
    {
        private FurnitureStoreXmlHandler xmlHandler;
        private ObservableCollection<FurnitureItem> furnitureItems;

        public MainWindow()
        {
            InitializeComponent();
            xmlHandler = new FurnitureStoreXmlHandler("furniture_schema.xsd");
            furnitureItems = new ObservableCollection<FurnitureItem>();
            ListViewFurniture.ItemsSource = furnitureItems;
        }

        private void LoadData_Click(object sender, RoutedEventArgs e)
        {
            furnitureItems.Clear();

            FurnitureStore store = new FurnitureStore();
            store.LoadFromXml("furniture_data.xml");

            foreach (var item in store.GetAllItems())
            {
                furnitureItems.Add(item);
            }
        }

        private void SaveData_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "furniture_data.xml";

            // Check if any furniture items exist
            if (furnitureItems.Count == 0)
            {
                MessageBox.Show("No furniture items to save!");
                return;
            }

            // Check if any furniture item has an empty name
            if (furnitureItems.Any(item => string.IsNullOrEmpty(item.Name)))
            {
                MessageBox.Show("Some furniture items have an empty name!");
                return;
            }

            // Загружаем существующий XML-файл
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);

            // Получаем корневой элемент
            XmlElement rootElement = xmlDoc.DocumentElement;

            // Удаляем все существующие элементы FurnitureItem
            XmlNodeList existingItems = rootElement.GetElementsByTagName("товар");
            for (int i = existingItems.Count - 1; i >= 0; i--)
            {
                rootElement.RemoveChild(existingItems[i]);
            }

            // Добавляем новые элементы FurnitureItem на основе данных из коллекции furnitureItems
            foreach (FurnitureItem item in furnitureItems)
            {
                // Skip saving the item if the name is empty
                if (string.IsNullOrEmpty(item.Name))
                    continue;

                // Создаем элемент для каждого объекта FurnitureItem
                XmlElement itemElement = xmlDoc.CreateElement("товар");

                // Создаем и добавляем элементы и атрибуты для каждого свойства FurnitureItem
                XmlElement nameElement = xmlDoc.CreateElement("название");
                nameElement.InnerText = item.Name;
                itemElement.AppendChild(nameElement);

                XmlElement typeElement = xmlDoc.CreateElement("вид_мебели");
                typeElement.InnerText = item.furnitureType.ToString();
                itemElement.AppendChild(typeElement);

                XmlElement priceElement = xmlDoc.CreateElement("цена");
                priceElement.InnerText = item.Price.ToString();
                itemElement.AppendChild(priceElement);

                XmlElement discountElement = xmlDoc.CreateElement("скидка");
                discountElement.InnerText = item.Discount.ToString();
                itemElement.AppendChild(discountElement);

                XmlElement manufacturerElement = xmlDoc.CreateElement("производитель");
                manufacturerElement.InnerText = item.Manufacturer;
                itemElement.AppendChild(manufacturerElement);

                XmlElement availabilityElement = xmlDoc.CreateElement("наличие_на_складе");
                availabilityElement.InnerText = item.StockAvailability.ToString();
                itemElement.AppendChild(availabilityElement);

                // Создаем элемент "габариты" и добавляем элементы для длины, ширины и высоты габаритов
                XmlElement dimensionsElement = xmlDoc.CreateElement("габариты");
                XmlElement lengthElement = xmlDoc.CreateElement("длина");
                lengthElement.InnerText = item.Dimensions.Length.ToString();
                dimensionsElement.AppendChild(lengthElement);
                XmlElement widthElement = xmlDoc.CreateElement("ширина");
                widthElement.InnerText = item.Dimensions.Width.ToString();
                dimensionsElement.AppendChild(widthElement);
                XmlElement heightElement = xmlDoc.CreateElement("высота");
                heightElement.InnerText = item.Dimensions.Height.ToString();
                dimensionsElement.AppendChild(heightElement);

                itemElement.AppendChild(dimensionsElement);

                // Добавляем элемент FurnitureItem в корневой элемент
                rootElement.AppendChild(itemElement);
            }

            // Сохраняем изменения в существующем XML-файле
            xmlDoc.Save(filePath);

            MessageBox.Show("Data saved successfully!");
        }
    }
}