﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace LibraryLab1
{
    public class FurnitureStoreXmlHandler
    {
        private readonly string filePath;

        public FurnitureStoreXmlHandler(string filePath)
        {
            this.filePath = filePath;
        }

        public List<FurnitureItem> GetAllFurnitureItems()
        {
            List<FurnitureItem> furnitureItems = new List<FurnitureItem>();

            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(filePath);

                XmlNodeList nodes = xmlDoc.SelectNodes("/мебельный_магазин/товар");
                foreach (XmlNode node in nodes)
                {
                    FurnitureItem item = new FurnitureItem();
                    item.Name = node.SelectSingleNode("название").InnerText;
                    item.furnitureType = (FurnitureType)Enum.Parse(typeof(FurnitureType), node.SelectSingleNode("вид_мебели").InnerText);
                    item.Price = Convert.ToDecimal(node.SelectSingleNode("цена").InnerText);
                    item.Discount = Convert.ToDecimal(node.SelectSingleNode("скидка").InnerText);
                    item.Manufacturer = node.SelectSingleNode("производитель").InnerText;
                    item.StockAvailability = Convert.ToInt32(node.SelectSingleNode("наличие_на_складе").InnerText);

                    XmlNode dimensionsNode = node.SelectSingleNode("габариты");
                    item.Dimensions = new Dimensions
                    {
                        Length = Convert.ToDecimal(dimensionsNode.SelectSingleNode("длина").InnerText),
                        Width = Convert.ToDecimal(dimensionsNode.SelectSingleNode("ширина").InnerText),
                        Height = Convert.ToDecimal(dimensionsNode.SelectSingleNode("высота").InnerText)
                    };

                    furnitureItems.Add(item);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading XML file: " + ex.Message);
            }

            return furnitureItems;
        }
    }
}
