﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace LibraryLab1

{
    public enum FurnitureType
    {
        Chair,
        Table,
        Sofa
    }
    public class FurnitureItem
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public string Manufacturer { get; set; }
        public int StockAvailability { get; set; }
        public FurnitureType furnitureType { get; set; }
        public Dimensions Dimensions { get; set; }
    }
}