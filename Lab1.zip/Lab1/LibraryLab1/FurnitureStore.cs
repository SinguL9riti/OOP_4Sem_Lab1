﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace LibraryLab1
{
    public class FurnitureStore
    {
        private readonly List<FurnitureItem> _items;

        public FurnitureStore()
        {
            _items = new List<FurnitureItem>();
        }

        public void LoadFromXml(string filePath)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(filePath);

            XmlNodeList itemNodes = doc.SelectNodes("/мебельный_магазин/товар");
            foreach (XmlNode itemNode in itemNodes)
            {
                FurnitureItem item = new FurnitureItem();
                item.Name = itemNode.SelectSingleNode("название").InnerText;
                if (Enum.TryParse(itemNode.SelectSingleNode("вид_мебели").InnerText, out FurnitureType furnitureType))
                    item.furnitureType = furnitureType;

                item.Price = decimal.Parse(itemNode.SelectSingleNode("цена").InnerText);
                item.Discount = decimal.Parse(itemNode.SelectSingleNode("скидка").InnerText);
                item.Manufacturer = itemNode.SelectSingleNode("производитель").InnerText;
                item.StockAvailability = int.Parse(itemNode.SelectSingleNode("наличие_на_складе").InnerText);

                XmlNode dimensionsNode = itemNode.SelectSingleNode("габариты");
                item.Dimensions = new Dimensions
                {
                    Length = decimal.Parse(dimensionsNode.SelectSingleNode("длина").InnerText),
                    Width = decimal.Parse(dimensionsNode.SelectSingleNode("ширина").InnerText),
                    Height = decimal.Parse(dimensionsNode.SelectSingleNode("высота").InnerText)
                };

                _items.Add(item);
            }
        }

        public void SaveToXml(string filePath)
        {
            XmlDocument doc = new XmlDocument();
            XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement root = doc.DocumentElement;
            doc.InsertBefore(xmlDeclaration, root);

            XmlElement rootElement = doc.CreateElement(string.Empty, "мебельный_магазин", string.Empty);
            doc.AppendChild(rootElement);

            foreach (FurnitureItem item in _items)
            {
                XmlElement itemElement = doc.CreateElement(string.Empty, "товар", string.Empty);
                rootElement.AppendChild(itemElement);

                AppendElement(doc, itemElement, "название", item.Name);
                AppendElement(doc, itemElement, "вид_мебели", item.furnitureType.ToString());
                AppendElement(doc, itemElement, "цена", item.Price.ToString());
                AppendElement(doc, itemElement, "скидка", item.Discount.ToString());
                AppendElement(doc, itemElement, "производитель", item.Manufacturer);
                AppendElement(doc, itemElement, "наличие_на_складе", item.StockAvailability.ToString());

                XmlElement dimensionsElement = doc.CreateElement(string.Empty, "габариты", string.Empty);
                itemElement.AppendChild(dimensionsElement);
                AppendElement(doc, dimensionsElement, "длина", item.Dimensions.Length.ToString());
                AppendElement(doc, dimensionsElement, "ширина", item.Dimensions.Width.ToString());
                AppendElement(doc, dimensionsElement, "высота", item.Dimensions.Height.ToString());
            }

            doc.Save(filePath);
        }

        private void AppendElement(XmlDocument doc, XmlElement parent, string elementName, string value)
        {
            XmlElement element = doc.CreateElement(string.Empty, elementName, string.Empty);
            element.InnerText = value;
            parent.AppendChild(element);
        }

        public List<FurnitureItem> GetAllItems()
        {
            return _items;
        }
    }
}
